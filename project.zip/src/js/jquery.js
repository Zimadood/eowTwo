$(window).width();
$(window).height();