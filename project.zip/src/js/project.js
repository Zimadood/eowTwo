document.title = "Gulp Example File With Minification";

document.querySelector(".title").textContent = "Gulp is Awesome.";

