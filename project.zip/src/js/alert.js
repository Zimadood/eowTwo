document.querySelector(".title").textContent = "I was not aware Text From Alert.js";

const message = () => {
    console.log("The Javascript was Transpiled ES5!");
}
message();